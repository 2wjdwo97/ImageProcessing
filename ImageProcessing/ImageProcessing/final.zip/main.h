#pragma once

#include "edgeDetect.h"
#include "vertexDetect.h"

#define IMAGE_NUMBER 4
